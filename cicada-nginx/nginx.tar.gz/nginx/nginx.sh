#!/bin/bash

BIN=/opt/yrd_soft/tengine/sbin/nginx
CONF=/etc/tengine/nginx.conf

case $1 in
    "test")
        $BIN -c $CONF -t
        ;;

    "status")
        ps -ef | grep nginx  | grep -v grep | grep -v nginx.sh
        ;;

    "start")
        $BIN -c $CONF
        ;;

    "stop")
        $BIN -c $CONF -s stop
        ;;

    "reload")
        $BIN -c $CONF -s reload
        ;;

    "restart")
        $BIN -c $CONF -s stop
        $BIN -c $CONF
        ;;

    *)
        echo -e "Usage $0 { test | status | start | stop | reload | restart }"
        ;;
esac

