#!/bin/bash

INSTALL_DIR=/opt/yrd_soft/tengine/
LOG_DIR=/opt/yrd_logs/tengine

### for CentOS7
# yum install -y cronolog

### install luajit, for record post data
LUAJIT_TAR=./LuaJIT-2.0.4.tar.gz
tar xf ${LUAJIT_TAR}

LUAJIT_DIR=./LuaJIT-2.0.4
LUAJIT_DST_DIR=/opt/yrd_soft/luajit-2.0.4

if [ ! -d $LUAJIT_DST_DIR ]
then
    cd ${LUAJIT_DIR}

    make PREFIX=$LUAJIT_DST_DIR
    make install PREFIX=/opt/yrd_soft/luajit-2.0.4
    ln -sf $LUAJIT_DST_DIR /opt/yrd_soft/luajit
    # 创建 /usr/lib64 目录下的软链接
    sudo ln -sf /opt/yrd_soft/luajit/lib/libluajit-5.1.so.2 /usr/lib64/libluajit-5.1.so.2

    cd ../
fi

### install tengine
TENGINE_TAR=./tengine-2.1.1.tar.gz
tar xf $TENGINE_TAR

JEMALLOC_TAR=./jemalloc-4.0.4.tar.gz
OPENSSL_TAR=./openssl-0.9.8zg.tar.gz
PCRE_TAR=./pcre-8.37.tar.bz2
NGX_DEVEL_KIT_TAR=./ngx-devel-kit-0.2.19.tar.gz
LUA_NGX_MODULE_TAR=./lua-nginx-module-0.10.2.tar.gz

tar xf $JEMALLOC_TAR
tar xf $OPENSSL_TAR
tar xf $PCRE_TAR
tar xf $NGX_DEVEL_KIT_TAR
tar xf $LUA_NGX_MODULE_TAR

cd tengine-2.1.1

JEMALLOC_DIR=../jemalloc-4.0.4
OPENSSL_DIR=../openssl-0.9.8zg
PCRE_DIR=../pcre-8.37
NGX_DEVEL_KIT_DIR=../ngx-devel-kit-0.2.19
LUA_NGX_MODULE_DIR=../lua-nginx-module-0.10.2

export LUAJIT_LIB=/opt/yrd_soft/luajit/lib
export LUAJIT_INC=/opt/yrd_soft/luajit/include/luajit-2.0

./configure --prefix=$INSTALL_DIR \
    --add-module=$NGX_DEVEL_KIT_DIR \
    --add-module=$LUA_NGX_MODULE_DIR \
    --with-http_ssl_module \
    --with-openssl=$OPENSSL_DIR \
    --with-openssl-opt=enable-tlsext \
    --with-pcre=$PCRE_DIR \
    # --with-jemalloc=path=$JEMALLOC_DIR \
    --with-http_gzip_static_module \
    --with-http_dav_module \
    --with-http_realip_module \
    --with-http_stub_status_module \
    --with-http_sub_module

make -j 8 && make install

cd ../

### 配置文件
sudo cp -r ./tengine /etc

### 创建logs目录
sudo mkdir -p $LOG_DIR/cicada
sudo chown -R nobody.nobody $LOG_DIR/

